# coding: utf-8
import os


datasets_root_train ='/home/pangyu/PycharmProjects/Dataset/VT5000/Train'
datasets_root_test ='/home/pangyu/PycharmProjects/Dataset/VT821'


train_data = os.path.join(datasets_root_train)
test_data = os.path.join(datasets_root_test)


