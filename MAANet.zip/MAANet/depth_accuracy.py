import torch
import numpy as np
class modal_accuracy:
    def __init__(self, depth, gt):
       self.depth=depth
       self.gt=gt

    def compute_accuracy(self):
        difference=abs(self.depth-self.gt)
        depth_op=1-self.depth
        difference_op=abs(depth_op-self.gt)
        a1=np.mean(difference.cpu().numpy())
        a2=np.mean(difference_op.cpu().numpy())
        if a1>a2:
           final=depth_op
        final_depth= self.depth
        final_difference=abs(final_depth-self.gt)
        final_a=1-final_difference
        return final_a


